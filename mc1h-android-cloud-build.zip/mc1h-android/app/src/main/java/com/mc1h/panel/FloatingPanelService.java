package com.mc1h.panel;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

public class FloatingPanelService extends Service {
    private static final String CHANNEL = "mc1h_floating_panel";
    private static final int BG = Color.rgb(9, 7, 17);
    private static final int CARD = Color.rgb(23, 18, 34);
    private static final int PURPLE = Color.rgb(168, 85, 247);
    private static final int MUTED = Color.rgb(190, 177, 211);
    private WindowManager windowManager;
    private View bubble;
    private View panel;
    private WindowManager.LayoutParams bubbleParams;
    private WindowManager.LayoutParams panelParams;
    private boolean panelVisible = false;

    @Override public void onCreate() {
        super.onCreate();
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        createNotificationChannel();
        startForeground(41, buildNotification());
        showBubble();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL, "mc1h painel flutuante", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Mantém disponível o botão flutuante mc1h");
            ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(channel);
        }
    }

    private Notification buildNotification() {
        Intent open = new Intent(this, MainActivity.class);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) flags |= PendingIntent.FLAG_IMMUTABLE;
        PendingIntent pending = PendingIntent.getActivity(this, 0, open, flags);
        Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
        return builder.setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("mc1h está ativo")
                .setContentText("Toque na logo flutuante para abrir ou fechar o painel")
                .setContentIntent(pending).setOngoing(true).build();
    }

    private int overlayType() {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
    }

    private void showBubble() {
        if (bubble != null) return;
        TextView logo = new TextView(this);
        logo.setText("mc1h");
        logo.setTextColor(Color.WHITE);
        logo.setTextSize(14);
        logo.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        logo.setGravity(Gravity.CENTER);
        logo.setElevation(dp(8));
        logo.setBackground(circle(PURPLE));
        bubble = logo;
        bubbleParams = new WindowManager.LayoutParams(dp(58), dp(58), overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT);
        bubbleParams.gravity = Gravity.TOP | Gravity.END;
        bubbleParams.x = dp(16);
        bubbleParams.y = dp(220);
        logo.setOnTouchListener(new View.OnTouchListener() {
            private float downX, downY;
            private int startX, startY;
            private boolean dragged;
            @Override public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        downX = event.getRawX(); downY = event.getRawY();
                        startX = bubbleParams.x; startY = bubbleParams.y; dragged = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        float dx = event.getRawX() - downX;
                        float dy = event.getRawY() - downY;
                        if (Math.abs(dx) > dp(5) || Math.abs(dy) > dp(5)) dragged = true;
                        bubbleParams.x = Math.max(0, startX - (int) dx);
                        bubbleParams.y = Math.max(0, startY + (int) dy);
                        try { windowManager.updateViewLayout(bubble, bubbleParams); } catch (Exception ignored) {}
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (!dragged) togglePanel();
                        return true;
                }
                return false;
            }
        });
        windowManager.addView(bubble, bubbleParams);
    }

    private void togglePanel() {
        if (panelVisible) hidePanel(); else showPanel();
    }

    private void showPanel() {
        if (panel != null) { panel.setVisibility(View.VISIBLE); panelVisible = true; return; }
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(14), dp(16), dp(16));
        box.setBackground(rounded(BG, 18, PURPLE));
        box.setElevation(dp(12));

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = label("mc1h  /  CONTROL", 17, Color.WHITE, true);
        top.addView(title, new LinearLayout.LayoutParams(0, -2, 1));
        TextView close = label("✕", 20, PURPLE, true);
        close.setGravity(Gravity.CENTER);
        top.addView(close, new LinearLayout.LayoutParams(dp(38), dp(38)));
        close.setOnClickListener(v -> hidePanel());
        box.addView(top);

        TextView subtitle = label("PAINEL FLUTUANTE ATIVO", 10, PURPLE, true);
        subtitle.setPadding(0, dp(3), 0, dp(12));
        box.addView(subtitle);
        addPanelRow(box, "Interface neon", "Demonstração visual local");
        addPanelRow(box, "Módulos de laboratório", "Sem conexão com jogos");
        addPanelRow(box, "Estado", "Executando em segundo plano");
        TextView hint = label("Arraste a logo para mover. Toque nela para abrir ou recolher este painel.", 10, MUTED, false);
        hint.setPadding(0, dp(12), 0, 0);
        box.addView(hint);

        panel = box;
        panelParams = new WindowManager.LayoutParams(dp(292), -2, overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        panelParams.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
        panelParams.y = dp(100);
        windowManager.addView(panel, panelParams);
        panelVisible = true;
    }

    private void addPanelRow(LinearLayout parent, String name, String detail) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.VERTICAL);
        row.setPadding(dp(11), dp(9), dp(11), dp(9));
        row.setBackground(rounded(CARD, 11, Color.rgb(55, 39, 77)));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.bottomMargin = dp(7);
        parent.addView(row, p);
        row.addView(label(name, 13, Color.WHITE, true));
        row.addView(label(detail, 10, MUTED, false));
    }

    private void hidePanel() {
        if (panel != null) panel.setVisibility(View.GONE);
        panelVisible = false;
    }

    private TextView label(String value, int size, int color, boolean bold) {
        TextView text = new TextView(this);
        text.setText(value); text.setTextSize(size); text.setTextColor(color);
        if (bold) text.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return text;
    }

    private GradientDrawable rounded(int color, int radius, int stroke) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(dp(radius)); d.setStroke(dp(1), stroke);
        return d;
    }

    private GradientDrawable circle(int color) {
        GradientDrawable d = new GradientDrawable();
        d.setShape(GradientDrawable.OVAL); d.setColor(color); d.setStroke(dp(2), Color.WHITE);
        return d;
    }

    private int dp(int value) { return (int) (value * getResources().getDisplayMetrics().density + 0.5f); }

    @Override public void onDestroy() {
        if (windowManager != null) {
            if (panel != null) try { windowManager.removeView(panel); } catch (Exception ignored) {}
            if (bubble != null) try { windowManager.removeView(bubble); } catch (Exception ignored) {}
        }
        panel = null; bubble = null;
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
