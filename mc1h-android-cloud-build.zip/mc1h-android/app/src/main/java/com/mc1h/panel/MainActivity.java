package com.mc1h.panel;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.content.SharedPreferences;
import android.app.ActivityManager;
import android.content.Context;
import android.os.Debug;

public class MainActivity extends Activity {
    private static final int BG=Color.rgb(9,7,17), CARD=Color.rgb(23,18,34), PURPLE=Color.rgb(168,85,247), MUTED=Color.rgb(190,177,211);
    private SharedPreferences prefs; private GameView game; private TextView memoryText; private Handler handler=new Handler();
    private final Runnable memoryUpdater=new Runnable(){ public void run(){ if(memoryText!=null){ ActivityManager.MemoryInfo mi=new ActivityManager.MemoryInfo(); ((ActivityManager)getSystemService(ACTIVITY_SERVICE)).getMemoryInfo(mi); long javaMb=Runtime.getRuntime().totalMemory()-Runtime.getRuntime().freeMemory(); long nativeMb=Debug.getNativeHeapAllocatedSize(); memoryText.setText("GAME PROCESS · Java heap: "+mb(javaMb)+" MB  |  Native heap: "+mb(nativeMb)+" MB\nDEVICE · Available RAM: "+mb(mi.availMem)+" MB  |  Low memory: "+(mi.lowMemory?"YES":"NO")); } handler.postDelayed(this,1000); }};
    private String mb(long b){return String.valueOf(b/1048576L);}
    @Override public void onCreate(Bundle b){super.onCreate(b); prefs=getSharedPreferences("mc1h_settings",MODE_PRIVATE); getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG); build();}
    private TextView label(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private GradientDrawable bg(int color){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(14));d.setStroke(dp(1),Color.rgb(65,43,91));return d;}
    private int dp(int x){return (int)(x*getResources().getDisplayMetrics().density+.5f);}
    private void build(){
      ScrollView scroll=new ScrollView(this);scroll.setBackgroundColor(BG);LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(16),dp(18),dp(16),dp(24));scroll.addView(root);
      root.addView(label("MC1H ARENA",27,Color.WHITE,true));root.addView(label("OFFLINE TRAINING LAB · v1.0",11,PURPLE,true));TextView intro=label("Jogo de treinamento integrado ao painel. ESP, assistência de mira e memória operam somente nesta arena de demonstração.",12,MUTED,false);intro.setPadding(0,dp(8),0,dp(12));root.addView(intro);
      game=new GameView(this);game.setBackground(bg(Color.rgb(15,12,24)));LinearLayout.LayoutParams gp=new LinearLayout.LayoutParams(-1,dp(310));gp.bottomMargin=dp(10);root.addView(game,gp);
      Button fire=new Button(this);fire.setText("DISPARAR / TESTAR ALVO");fire.setTextColor(Color.WHITE);fire.setBackground(bg(PURPLE));root.addView(fire,new LinearLayout.LayoutParams(-1,dp(48)));fire.setOnClickListener(v->game.shoot());
      section(root,"ESP · VISUALIZAÇÃO DE ENTIDADES");toggle(root,"ESP ativado","esp",true);toggle(root,"Esqueleto","skeleton",true);toggle(root,"Barra de vida","health",true);toggle(root,"Caixa 2D","box2d",true);toggle(root,"Caixa 3D (perspectiva)","box3d",false);toggle(root,"Nome e distância","labels",true);
      section(root,"AIM ASSIST · ARENA PRÓPRIA");toggle(root,"Assistência de mira ativada","aim",true);choice(root,"Região do alvo",new String[]{"Cabeça","Pescoço","Peito","Abdômen","Braços","Pernas"},"region");slider(root,"FOV",10,180,90,"fov");slider(root,"Suavização",1,100,35,"smooth");slider(root,"Distância máxima",20,500,180,"range");
      section(root,"MEMORY READER · PROCESSO DO JOGO");memoryText=label("Coletando métricas…",12,Color.WHITE,false);memoryText.setPadding(dp(12),dp(12),dp(12),dp(12));memoryText.setBackground(bg(CARD));root.addView(memoryText);
      Button reset=new Button(this);reset.setText("REINICIAR ARENA");reset.setOnClickListener(v->game.resetTargets());root.addView(reset,new LinearLayout.LayoutParams(-1,dp(46)));
      Button floating=new Button(this);floating.setText("ATIVAR LOGO FLUTUANTE MC1H");root.addView(floating,new LinearLayout.LayoutParams(-1,dp(46)));floating.setOnClickListener(v->{if(Build.VERSION.SDK_INT>=23&&!Settings.canDrawOverlays(this)){startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:"+getPackageName())));Toast.makeText(this,"Permita sobreposição e toque novamente",Toast.LENGTH_LONG).show();return;}Intent i=new Intent(this,FloatingPanelService.class);if(Build.VERSION.SDK_INT>=26)startForegroundService(i);else startService(i);});
      root.addView(label("Nota: o leitor mede o processo MC1H Arena e a RAM geral disponível. Não lê a memória privada de outros aplicativos.",10,MUTED,false));setContentView(scroll);
    }
    private void section(LinearLayout root,String s){TextView t=label(s,13,PURPLE,true);t.setPadding(0,dp(17),0,dp(8));root.addView(t);}
    private void toggle(LinearLayout root,String title,String key,boolean def){Switch sw=new Switch(this);sw.setText(title);sw.setTextColor(Color.WHITE);sw.setPadding(dp(12),dp(7),dp(12),dp(7));sw.setBackground(bg(CARD));sw.setChecked(prefs.getBoolean(key,def));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=dp(6);root.addView(sw,p);sw.setOnCheckedChangeListener((b,c)->{prefs.edit().putBoolean(key,c).apply();if(game!=null)game.invalidate();});sw.setOnClickListener(v->{if(game!=null)game.invalidate();});}
    private void choice(LinearLayout root,String title,String[] values,String key){LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(12),dp(8),dp(12),dp(8));card.setBackground(bg(CARD));root.addView(card);card.addView(label(title,12,Color.WHITE,true));Spinner sp=new Spinner(this);sp.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,values));sp.setSelection(java.util.Arrays.asList(values).indexOf(prefs.getString(key,"Cabeça"))<0?0:java.util.Arrays.asList(values).indexOf(prefs.getString(key,"Cabeça")));card.addView(sp);sp.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onItemSelected(android.widget.AdapterView<?>a,View v,int pos,long id){prefs.edit().putString(key,values[pos]).apply();if(game!=null)game.invalidate();}public void onNothingSelected(android.widget.AdapterView<?>a){}});}
    private void slider(LinearLayout root,String title,int min,int max,int def,String key){LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(12),dp(8),dp(12),dp(8));card.setBackground(bg(CARD));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=dp(6);root.addView(card,p);TextView tv=label(title+": "+prefs.getInt(key,def),12,Color.WHITE,true);card.addView(tv);SeekBar sb=new SeekBar(this);sb.setMax(max-min);sb.setProgress(prefs.getInt(key,def)-min);card.addView(sb);sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar s,int v,boolean u){int n=v+min;tv.setText(title+": "+n);if(u)prefs.edit().putInt(key,n).apply();if(game!=null)game.invalidate();}public void onStartTrackingTouch(SeekBar s){}public void onStopTrackingTouch(SeekBar s){}});}
    @Override protected void onResume(){super.onResume();handler.post(memoryUpdater);}@Override protected void onPause(){super.onPause();handler.removeCallbacks(memoryUpdater);}
}
