package com.mc1h.panel;

import android.app.Activity;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int BG = Color.rgb(9, 7, 17);
    private static final int CARD = Color.rgb(23, 18, 34);
    private static final int PURPLE = Color.rgb(168, 85, 247);
    private static final int MUTED = Color.rgb(180, 166, 204);
    private SharedPreferences prefs;
    private LinearLayout content;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("mc1h_settings", MODE_PRIVATE);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        buildUi();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(20), dp(24), dp(20), dp(28));
        scroll.addView(content);

        TextView brand = text("mc1h", 30, Color.WHITE, true);
        content.addView(brand);
        TextView subtitle = text("ANDROID CONTROL PANEL  •  v0.1.0", 11, PURPLE, true);
        subtitle.setLetterSpacing(0.08f);
        content.addView(subtitle);
        TextView note = text("Painel de interface e laboratório de recursos.\nSem conexão ou alteração no Standoff 2.", 13, MUTED, false);
        note.setPadding(0, dp(10), 0, dp(18));
        content.addView(note);

        addSection("VISUAL SETTINGS", "Personalização da interface");
        addToggle("Neon accents", "Destaques roxo neon", "neon", true);
        addToggle("Compact mode", "Reduz o espaçamento do painel", "compact", false);

        addSection("LAB MODULES", "Demonstrações locais — não conectadas ao jogo");
        addToggle("ESP preview", "Ativa somente uma prévia visual demonstrativa", "esp_preview", false);
        addToggle("Aim settings preview", "Exibe controles de sensibilidade de demonstração", "aim_preview", false);
        addToggle("Performance monitor", "Mostra o estado local do painel", "monitor", true);

        addSection("PROJECT STATUS", "Estado da implementação");
        addInfo("Target", "Standoff 2 oficial — integração não implementada");
        addInfo("Environment", "Android 10+ • aplicativo nativo Java");
        addInfo("Build status", "Código-fonte inicial; APK ainda não compilado");

        TextView footer = text("mc1h  /  BUILD WITH EVIDENCE", 10, MUTED, true);
        footer.setGravity(Gravity.CENTER);
        footer.setPadding(0, dp(24), 0, 0);
        content.addView(footer);
        setContentView(scroll);
    }

    private void addSection(String title, String hint) {
        TextView heading = text(title, 13, PURPLE, true);
        heading.setPadding(0, dp(16), 0, dp(3));
        content.addView(heading);
        TextView caption = text(hint, 11, MUTED, false);
        caption.setPadding(0, 0, 0, dp(9));
        content.addView(caption);
    }

    private void addToggle(String title, String description, String key, boolean defaultValue) {
        LinearLayout card = new LinearLayout(this);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(dp(14), dp(12), dp(12), dp(12));
        card.setOrientation(LinearLayout.HORIZONTAL);
        card.setBackground(roundRect(CARD, 14));
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2);
        cp.bottomMargin = dp(8);
        content.addView(card, cp);

        LinearLayout labels = new LinearLayout(this);
        labels.setOrientation(LinearLayout.VERTICAL);
        TextView name = text(title, 14, Color.WHITE, true);
        TextView desc = text(description, 11, MUTED, false);
        labels.addView(name);
        labels.addView(desc);
        card.addView(labels, new LinearLayout.LayoutParams(0, -2, 1));

        Switch toggle = new Switch(this);
        toggle.setButtonTintList(null);
        toggle.setChecked(prefs.getBoolean(key, defaultValue));
        toggle.setOnCheckedChangeListener((button, checked) -> {
            prefs.edit().putBoolean(key, checked).apply();
            Toast.makeText(this, title + (checked ? " enabled" : " disabled"), Toast.LENGTH_SHORT).show();
        });
        card.addView(toggle);
    }

    private void addInfo(String label, String value) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(14), dp(11), dp(14), dp(11));
        card.setBackground(roundRect(CARD, 12));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.bottomMargin = dp(7);
        content.addView(card, p);
        card.addView(text(label.toUpperCase(), 10, PURPLE, true));
        card.addView(text(value, 12, Color.WHITE, false));
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(value);
        v.setTextSize(size);
        v.setTextColor(color);
        if (bold) v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return v;
    }

    private GradientDrawable roundRect(int color, int radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radiusDp));
        d.setStroke(dp(1), Color.rgb(55, 39, 77));
        return d;
    }

    private int dp(int value) { return (int) (value * getResources().getDisplayMetrics().density + 0.5f); }
}
