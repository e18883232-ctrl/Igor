# MC1H Arena (Android)

Projeto Android nativo em Java, criado para compilar via GitHub Actions usando apenas o celular.

## O que esta versão implementa
- Arena offline 2D de treino com quatro alvos fictícios.
- Alvos com vida e botão/toque para disparar e reduzir a vida.
- ESP local sobre os alvos desta arena: caixa 2D, caixa 3D ilustrativa, esqueleto, barra de vida, nome e distância aproximada.
- Aim assist demonstrativo e funcional dentro da arena: seleciona um alvo da própria arena, move suavemente a linha de mira e permite escolher região (cabeça, pescoço, peito, abdômen, braços ou pernas), FOV, suavização e distância.
- Leitor de diagnóstico do próprio processo MC1H (heap Java e heap Native) e RAM disponível do aparelho. Não lê a memória privada de outros apps.
- Serviço opcional com logo flutuante para abrir/recolher um painel compacto.
- Preferências salvas localmente.

## Limites
ESP e assistência de mira operam apenas nos alvos simulados dentro do MC1H Arena. O leitor de memória mostra métricas do próprio processo e do dispositivo, não endereços/valores da memória privada de outros jogos. Não há integração com Standoff 2 ou qualquer jogo externo.

## Compilar pelo GitHub
1. Envie o conteúdo desta pasta para a raiz do repositório (incluindo `.github/workflows/android-apk.yml`).
2. Abra **Actions** → **Build MC1H Arena APK** → **Run workflow**.
3. Quando terminar, abra a execução e baixe o artefato `mc1h-arena-debug-apk`.
4. Extraia o artefato ZIP e instale `app-debug.apk` no Android. Talvez seja necessário permitir instalação por essa fonte.

Requisitos da compilação: JDK 17, Gradle 8.2.1, Android SDK 34 e Build Tools 34.0.0.
