# mc1h Android Panel — 0.1.0

Native Android starter project for Android 10 and newer. The app contains a dark/neon-purple settings panel and local preference toggles.

## Scope

- Native Java Android app; minSdk 23, targetSdk 29.
- Persistent UI settings using SharedPreferences.
- Demonstration-only ESP and aim-settings toggles. They do not read or write another app's memory, inspect game entities, inject code, or alter Standoff 2.
- No game integration has been implemented or verified.

## Build requirements

- JDK 17
- Android SDK Platform 34 and Build Tools installed
- Gradle 8.2-compatible environment
- Android Gradle Plugin 8.2.2 (resolved by Gradle from Google Maven)

Open this folder as a project in Android Studio or a compatible Android IDE, allow Gradle sync, then build the `app` debug variant. The resulting APK is normally at `app/build/outputs/apk/debug/app-debug.apk`.

## Phone-only workflow

On Android, use an Android IDE that supports importing Gradle projects, JDK 17, and Android SDK 34. Import the extracted project folder, sync Gradle, and build the debug APK. Availability of these components depends on the IDE; this project has not been compiled in this environment.

## Current validation

Source and project structure created. APK build, installation, Android 10 runtime, and device UI checks have not been run because no Android SDK/device build toolchain is connected here.

## Cloud build (no AndroidIDE required)

This repository includes `.github/workflows/android-apk.yml`. After uploading the project to a GitHub repository, open **Actions → Build Android APK → Run workflow**. The workflow installs JDK 17, Gradle 8.2.1, Android SDK Platform 34 and Build Tools 34.0.0, then builds `assembleDebug`. Download `mc1h-debug-apk` from the completed workflow run's Artifacts section. A GitHub account and a repository containing these files are required. This workflow has been prepared locally but has not been executed in this environment.
